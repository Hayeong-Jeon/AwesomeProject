// AdminReceiver.java
package com.example.p3;

import android.annotation.TargetApi;
import android.app.admin.DeviceAdminReceiver;
import android.os.Build;

@TargetApi(Build.VERSION_CODES.FROYO)
public class AdminReceiver extends DeviceAdminReceiver {
}
